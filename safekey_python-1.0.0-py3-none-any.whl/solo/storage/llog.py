import logging

logging.basicConfig(format='* %(relativeCreated)6dms %(filename)s:%(lineno)d %(message)s', level=logging.INFO)
log = logging.getLogger('comm')


def set_debug_messages2(a: int):
    if a == 1:
        logging.basicConfig(format='* %(relativeCreated)6dms %(filename)s:%(lineno)d %(message)s', level=logging.INFO)
    elif a == 0:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s',
                            handlers=[logging.FileHandler("activation.log")])
        # handlers=[logging.FileHandler("activation.log"), logging.StreamHandler()])
