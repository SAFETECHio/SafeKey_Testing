# Copyright (C) Nitrokey 2019

import struct
from enum import Enum

from attr import dataclass


class CommCommands(Enum):
    WRITE = 0x01  # send command
    READ = 0x02  # receive result


@dataclass
class CmdTrans:
    header = b'\0' * 14
    command_id: int
    packets_count: int
    packet_num: int
    chunk_size: int
    this_chunk_length: int
    data: bytes

    def wrap(self, data: int) -> bytes:
        return struct.pack("B", data)

    def construct(self) -> bytes:
        return self.header \
               + self.wrap(self.command_id) \
               + self.wrap(self.packet_num) \
               + self.wrap(self.packets_count) \
               + self.wrap(self.chunk_size) \
               + self.wrap(self.this_chunk_length) \
               + self.data

    @staticmethod
    def overhead_bytes_count() -> int:
        return 1 + 1 + 1 + 1 + 1 + len(CmdTrans.header)


class Command(Enum):
    STATUS = 0x00,
    PING = 0x01,
    READ = 0x02,
    WRITE = 0x03,
    TEST_CLEAR = 0x04,
    STORAGE_FREE = 0x05,
    REMOVE_DATA = 0x06,
    LIST_KEYS = 0x07,
    LOGIN = 0x08,
    CLEAR_SESSION = 0x09,
    PIN_SET = 0x0A,
    PIN_CHANGE = 0x0B,
    PIN_ATTEMPTS = 0x0C,
    FACTORY_RESET = 0x0D,
    BACKUP_READ = 0x0E,
    BACKUP_WRITE = 0x0F,
    BACKUP_BEGIN = 0x10,
    BACKUP_FINISH = 0x11,
    ACTIVATION_BEGIN = 0x12,
    ACTIVATION_FINISH = 0x13,
    GET_RANDOM = 0x14,
    TEST_REBOOT = 0x15,
    CMD_UNLOCK_GENERATE = 0x16,
    CMD_UNLOCK = 0x17,

    def as_bytes(self):
        return struct.pack("B", self.value[0])


class ExecError(Enum):
    SUCCESS = 0x00,
    CTAP2_ERR_CBOR_PARSING = 0x10,
    REQ_AUTH = 0xF0,
    INVALID_PIN = 0xF1,
    ERR_NOT_ALLOWED = 0xF2,
    ERR_BAD_FORMAT = 0xF3,
    ERR_USER_NOT_PRESENT = 0xF4,
    ERR_FAILED_LOADING_DATA = 0xF5,
    ERR_INVALID_CHECKSUM = 0xF6,
    ERR_ALREADY_IN_DATABASE = 0xF7,
    ERR_NOT_FOUND = 0xF8,
    ERR_ASSERT_FAILED = 0xF9,
    ERR_FEATURE_INACTIVE = 0xFA,
    ERR_INVALID_SIGNATURE = 0xFB,
    INVALID_COMMAND = 0xFF,
