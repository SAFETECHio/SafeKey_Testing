from collections import Counter
from pprint import pprint
from struct import pack
from types import FunctionType

from ecdsa import SigningKey, NIST256p
from fido2 import cbor
from fido2.utils import sha256

from solo.client import SoloClient
from solo.storage.communication import send_and_receive, device_send, device_receive, set_global_appid, \
    set_debug_messages
from solo.storage.types import Command, ExecError


def helper_set_activation_state(solo_client, state: int, key: bytes, quiet=True):
    if quiet:
        set_debug_messages(0)
    _, data = send_and_receive(solo_client, Command.ACTIVATION_BEGIN)
    data = cbor.loads(data)[0]
    data_to_sign = helper_get_data_for_state(data, state=state)
    signature = helper_ecc_sign(data_to_sign, key=key, quiet=True)
    d = dict(SIGNATURE=signature, STATE=state)
    success, response = send_and_receive(solo_client, Command.ACTIVATION_FINISH, d)
    set_debug_messages(1)
    return success


def helper_confirm_device_activated(solo_client):
    send_and_receive(solo_client, Command.CLEAR_SESSION)


def helper_confirm_device_inactive(solo_client):
    send_and_receive(solo_client, Command.CLEAR_SESSION, expected_error=ExecError.ERR_FEATURE_INACTIVE)


def compare_cbor_dict(read_data_bytes: bytes, test_data: dict) -> None:
    assert read_data_bytes, "Read data are empty"
    print(f'Record stats: CBOR length {len(read_data_bytes)}')
    read_data, nulls = cbor.loads(read_data_bytes)
    print(Counter(read_data_bytes))
    pprint(read_data)
    # pprint(nulls)
    assert not isinstance(read_data, int)
    for k, v in test_data.items():
        k: bytes
        if k.startswith('_'): continue
        assert read_data[k] == v
    assert '_TP' not in read_data

    # nulls should be empty
    assert not nulls
    # Not parsed data should be \0
    for b in nulls:
        if b:
            assert b in [0, 0xFF], "Not parsed data should be null"


def helper_get_space(solo_client: SoloClient):
    assert device_send(solo_client, {}, Command.STORAGE_FREE)[0]
    command, read_data_bytes = device_receive(solo_client)
    assert command == Command.STORAGE_FREE.value[0]
    return cbor.loads(read_data_bytes)[0]


def helper_test_list_key_equal(solo_client: SoloClient, expected: list):
    read_data = []
    # 8 IDs per page
    for i in range(10):
        success, read_data_bytes = send_and_receive(solo_client, Command.LIST_KEYS, dict(PAGE=i))
        assert read_data_bytes, "Read data are empty"
        paged_read_data, nulls = cbor.loads(read_data_bytes)
        read_data += paged_read_data

    assert read_data == expected


def get_data_dict(ID, length: int = None):
    data = b'test data for ' + ID
    d = dict(ID=ID, DATA=data)
    if length and len(data) < length:
        from math import ceil
        data = data.decode() * (ceil(length / len(data)))
        data = data[:length]
        d['DATA'] = data.encode()
    return d


def helper_get_counter(solo_client: SoloClient):
    s, read_data_bytes = send_and_receive(solo_client, Command.PIN_ATTEMPTS)
    read_data, nulls = cbor.loads(read_data_bytes)
    counter = read_data['COUNTER']
    return counter


def helper_get_data(i: int, data_length):
    return get_data_dict('AAAB{:02}'.format(i).encode(), data_length)


def helper_test_read(solo_client, records_to_write, helper_get_data: FunctionType, remove: bool = False):
    for i in range(records_to_write):
        d = helper_get_data(i)
        s, read_bytes = send_and_receive(solo_client, Command.READ, d)
        compare_cbor_dict(read_bytes, d)
        print(f'Confirmed record {i} is valid')
        if remove:
            send_and_receive(solo_client, Command.REMOVE_DATA, d)


def helper_set_origin_int(i: int):
    appid = b'C' * 16 + '{:02}'.format(i + 1).encode()
    set_global_appid(appid)


def helper_ecc_sign(data: bytes, key: bytes, quiet: bool = False) -> bytes:
    import binascii

    # sk_name = 'ECC_key.pem'
    # sk = SigningKey.from_pem(open(sk_name).read())
    skb = key
    # skb = binascii.unhexlify(skb)
    sk = SigningKey.from_string(skb, curve=NIST256p)
    data_sha = sha256(data)
    sig = sk.sign_digest(data_sha)
    if not quiet:
        print(f'DATA SHA {binascii.hexlify(data_sha)}')
        print(f"sig", binascii.hexlify(sig))

    return sig


def helper_get_data_for_state(data: dict, state: int) -> bytes:
    return data['NONCE'] + pack('<B', state)


def helper_test_write(data_length, records_to_write, solo_client):
    for i in range(records_to_write):
        d = helper_get_data(i, data_length)
        send_and_receive(solo_client, Command.WRITE, d)
